// Nonnon COM : IHTMLDocument2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Compatibility
//
//	95   + IE3 : not checked
//	95   + IE4 : not checked
//	98SE + IE5 : not checked
//	2000 + IE6 : get_Document() failed
//	XP   + IE6 : not checked
//	XP   + IE7 : not checked
//	XP   + IE8 : OK
//	7    + IE8 : OK / restricted under Protected Mode


// [Mechanism]
//
//	almost functions are the same as IWebBrowser2
//	almost IDispatch-derived interfaces seems to be sink-able (see mshtmdid.h)
//	but not function (event IID is not known)
//
//	using IHTMLDocument2 is harder than IWebBrowser2
//	IHTMLWindow2_navigate() cannot change DOS path(c:\) to URL(file:///c:/)




#ifndef _H_NONNON_WIN32_COM_IHTMLDOCUMENT2
#define _H_NONNON_WIN32_COM_IHTMLDOCUMENT2




#include "./com.c"




#define N_IHTMLDOCUMENT2_TIMEOUT ( 1000 )




BSTR
n_IHTMLDocument2_uri( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	// [!] : use n_com_bstr_exit() to free


	BSTR bstr;

	IHTMLDocument2_get_URL( _this, &bstr );


	return bstr;
}

BSTR
n_IHTMLDocument2_status( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	// [!] : use n_com_bstr_exit() to free


	IHTMLWindow2 *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( _this, &hw2 );
	if ( hw2 == NULL ) { return n_com_bstr_init_literal( "" ); }


	BSTR bstr;

	IHTMLWindow2_get_status( hw2, &bstr );

	n_com_release( hw2 );


	return bstr;
}

void
n_IHTMLDocument2_back( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return; }


	IHTMLWindow2 *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( _this, &hw2 );
	if ( hw2 == NULL ) { return; }


	IOmHistory *oh = NULL;
	IHTMLWindow2_get_history( hw2, &oh );

	if ( oh != NULL )
	{

		// [x] : VARIANT is needed : MSDN document is inaccurate

		VARIANT v; VariantInit( &v );

		V_VT( &v ) = VT_I4;
		V_I4( &v ) = 1;

		IOmHistory_back( oh, &v );

	}

	n_com_release( oh );


	n_com_release( hw2 );


	return;
}

void
n_IHTMLDocument2_next( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return; }


	IHTMLWindow2 *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( _this, &hw2 );
	if ( hw2 == NULL ) { return; }


	IOmHistory *oh = NULL;
	IHTMLWindow2_get_history( hw2, &oh );

	if ( oh != NULL )
	{

		// [x] : VARIANT is needed : MSDN document is inaccurate

		VARIANT v; VariantInit( &v );

		V_VT( &v ) = VT_I4;
		V_I4( &v ) = 1;

		IOmHistory_forward( oh, &v );

	}

	n_com_release( oh );


	n_com_release( hw2 );


	return;
}

void
n_IHTMLDocument2_go( IHTMLDocument2 *_this, BSTR uri )
{

	if ( _this == NULL ) { return; }


	// [!] : not function
	//
	//	IHTMLDocument2_put_URL() : nothing happen
	//	IHTMLWindow2_navigate()  : a new Explorer window will appear


	IHTMLWindow2 *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( _this, &hw2 );
	if ( hw2 == NULL ) { return; }


	IHTMLWindow2_navigate( hw2, uri );
/*

	IHTMLLocation *hl = NULL;
	IHTMLWindow2_get_location( hw2, &hl );

	if ( hl != NULL )
	{
		IHTMLLocation_assign( hl, uri );
	}

	n_com_release( hl  );
*/

	n_com_release( hw2 );


	return;
}

HWND
n_IHTMLDocument2_hgui( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return NULL; }


	IOleWindow *ow = NULL;
	n_com_interface( _this, n_guid_IID_IOleWindow, (void*) &ow );

	if ( ow == NULL ) { return NULL; }


	HWND hgui = NULL;
	IOleWindow_GetWindow( ow, &hgui );
	n_com_release( ow );


	return GetParent( hgui );
}

void
n_IHTMLDocument2_focus( IHTMLDocument2 *_this )
{

	if ( _this == NULL ) { return; }


	IHTMLWindow2 *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( _this, &hw2 );

	if ( hw2 != NULL )
	{
		IHTMLWindow2_focus( hw2 );
	} else {
		SetForegroundWindow( n_IHTMLDocument2_hgui( _this ) );
	}

	n_com_release( hw2 );


	return;
}

HWND
n_IHTMLDocument2_embed( IHTMLDocument2 *_this, HWND hwnd_parent )
{

	HWND hgui = n_IHTMLDocument2_hgui( _this );


	SetParent( hgui, hwnd_parent );


	return hgui;
}

void
n_IHTMLDocument2_exit( IHTMLDocument2 *_this, DWORD *cookie )
{

	if ( _this == NULL ) { return; }


	if ( cookie != NULL )
	{
		n_com_override_exit( _this, n_guid_IID_IDispatch, cookie );
	}

	n_com_release( _this );


	return;
}

void
n_IHTMLDocument2_init
(
	IHTMLDocument2     **ret_interface,
	HTMLDocumentEvents  *eventsink,
	DWORD               *cookie,
	HWND                *ret_hgui,
	HWND                 hwnd_parent,
	n_posix_char        *uri
)
{

	// [Needed] : n_com_init(); and n_com_exit();

	// [Needed] : hwnd_parent needs to be static control

	// [x] : Win95 + IE3
	//
	//	IE3 doesn't support "about:*" like "about:blank", "about:home"

	// [x] : CLSID_WebBrowser/CLSID_WebBrowser_V1 : hangup


	if ( ret_interface == NULL ) { return; }

	*ret_interface = NULL;
	if ( ret_hgui != NULL ) { *ret_hgui = NULL; }


	IHTMLDocument2 *_this = NULL;

	{

		IWebBrowser2 *wb = NULL;
		n_com_class( n_guid_CLSID_InternetExplorerMedium, n_guid_IID_IWebBrowser2, (void*) &wb );
		if ( wb == NULL ) { n_com_class( n_guid_CLSID_InternetExplorer, n_guid_IID_IWebBrowser2, (void*) &wb ); }
		if ( wb == NULL ) { return; }


		if ( n_string_is_empty( uri ) )
		{

			IWebBrowser2_GoHome( wb );

		} else {

			BSTR bstr = n_com_bstr_init( uri );

			IWebBrowser2_Navigate( wb, uri, NULL, NULL, NULL, NULL );

			n_com_bstr_exit( bstr );

		}


		IDispatch *disp = NULL;

		u32 timeout = n_posix_tickcount() + N_IHTMLDOCUMENT2_TIMEOUT;
		while( 1 )
		{

			IWebBrowser2_get_Document( wb, (void*) &disp );
			if ( disp != NULL ) { break; }

			if ( timeout < n_posix_tickcount() ) { break; }

		}

		n_com_interface( disp, n_guid_IID_IHTMLDocument2, (void*) &_this );

		n_com_release( disp );


		n_com_release( wb );

	}


	if ( _this == NULL ) { n_posix_debug_literal( "NULL" ); }

	*ret_interface = _this;


	// [!] : optional

	if ( ( eventsink != NULL )&&( cookie != NULL ) )
	{

		// [x] : Win2000 + IE6 : not function

		*cookie = 0;

		u32 timeout = n_posix_tickcount() + N_IHTMLDOCUMENT2_TIMEOUT;
		while( 1 )
		{

			n_com_override_init( _this, n_guid_DIID_HTMLDocumentEvents, (void*) eventsink, cookie );
			if ( cookie != 0 ) { break; }

			if ( timeout < n_posix_tickcount() ) { break; }

		}

	}


	// Embedding

	HWND hgui = NULL;

	u32 timeout = n_posix_tickcount() + N_IHTMLDOCUMENT2_TIMEOUT;
	while( 1 )
	{

		hgui = n_IHTMLDocument2_embed( _this, hwnd_parent );
		if ( hgui != NULL ) { break; }

		if ( timeout < n_posix_tickcount() ) { break; }

	}

	if ( ret_hgui != NULL ) { *ret_hgui = hgui; }


	if ( *cookie  ==    0 ) { n_posix_debug_literal( "cookie"   ); }
	if ( ret_hgui == NULL ) { n_posix_debug_literal( "ret_hgui" ); }


	return;
}


#endif // _H_NONNON_WIN32_COM_IHTMLDOCUMENT2


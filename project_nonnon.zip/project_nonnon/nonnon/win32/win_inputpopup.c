// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_INPUTPOPUP
#define _H_NONNON_WIN32_WIN_INPUTPOPUP




#include "./win.c"

#include "./win_button.c"
#include "./win_popup.c"
#include "./win_txtbox.c"




#define KEY_MAX ( 10 + 26 + 3 )
#define BTN_MAX KEY_MAX


static HWND          n_win_inputpopup_hpopup     = NULL;
static HWND          n_win_inputpopup_target     = NULL;
static n_win_txtbox *n_win_inputpopup_txtbox     = NULL;
static n_win_txtbox *n_win_inputpopup_txtbox_prv = NULL;

static n_posix_bool  n_win_inputpopup_silent_onoff = n_posix_false;


#define N_WIN_INPUTPOPUP_MODE_SYSTEM   ( 0 )
#define N_WIN_INPUTPOPUP_MODE_ORIGINAL ( 1 )


typedef struct {

	HWND         hwnd;
	n_win_button hbtn[ BTN_MAX ];

	int          mode;
	n_type_gfx   size;
	n_type_gfx   gap;
	n_type_gfx   pad;
	n_type_gfx   csx_all;
	n_type_gfx   csy_all;
	n_type_gfx   csx;
	n_type_gfx   csy;
	n_type_gfx   round;
	n_type_gfx   scale;

	u32          color_outer;
	u32          color_inner;

	n_bmp        bmp_desktop;
	n_bmp        bmp_buttons;

	n_type_gfx   shadow_u;
	n_type_gfx   shadow_d;
	n_type_gfx   shadow_l;
	n_type_gfx   shadow_r;

	UINT         slide_timer_id;
	double       slide_timer_sy;
	u32          slide_timer_unit;
	double       slide_timer_step;
	u32          slide_timer_tick;
	n_posix_bool slide_timer_is_running;

} n_win_inputpopup;


#define n_win_inputpopup_zero( p ) n_memory_zero( p, sizeof( n_win_inputpopup ) )


static n_win_inputpopup n_win_inputpopup_instance;




static n_posix_char *n_win_inputpopup_keytable_upper[] = {

	n_posix_literal( "0" ),
	n_posix_literal( "1" ),
	n_posix_literal( "2" ),
	n_posix_literal( "3" ),
	n_posix_literal( "4" ),
	n_posix_literal( "5" ),
	n_posix_literal( "6" ),
	n_posix_literal( "7" ),
	n_posix_literal( "8" ),
	n_posix_literal( "9" ),
	n_posix_literal( "A" ),
	n_posix_literal( "B" ),
	n_posix_literal( "C" ),
	n_posix_literal( "D" ),
	n_posix_literal( "E" ),
	n_posix_literal( "F" ),
	n_posix_literal( "G" ),
	n_posix_literal( "H" ),
	n_posix_literal( "I" ),
	n_posix_literal( "J" ),
	n_posix_literal( "K" ),
	n_posix_literal( "L" ),
	n_posix_literal( "M" ),
	n_posix_literal( "N" ),
	n_posix_literal( "O" ),
	n_posix_literal( "P" ),
	n_posix_literal( "Q" ),
	n_posix_literal( "R" ),
	n_posix_literal( "S" ),
	n_posix_literal( "T" ),
	n_posix_literal( "U" ),
	n_posix_literal( "V" ),
	n_posix_literal( "W" ),
	n_posix_literal( "X" ),
	n_posix_literal( "Y" ),
	n_posix_literal( "Z" ),
	n_posix_literal( " " ),
	n_posix_literal( "Caps" ),
	n_posix_literal( "BS" )

};

static n_posix_char *n_win_inputpopup_keytable_lower[] = {

	n_posix_literal( "0" ),
	n_posix_literal( "1" ),
	n_posix_literal( "2" ),
	n_posix_literal( "3" ),
	n_posix_literal( "4" ),
	n_posix_literal( "5" ),
	n_posix_literal( "6" ),
	n_posix_literal( "7" ),
	n_posix_literal( "8" ),
	n_posix_literal( "9" ),
	n_posix_literal( "a" ),
	n_posix_literal( "b" ),
	n_posix_literal( "c" ),
	n_posix_literal( "d" ),
	n_posix_literal( "e" ),
	n_posix_literal( "f" ),
	n_posix_literal( "g" ),
	n_posix_literal( "h" ),
	n_posix_literal( "i" ),
	n_posix_literal( "j" ),
	n_posix_literal( "k" ),
	n_posix_literal( "l" ),
	n_posix_literal( "m" ),
	n_posix_literal( "n" ),
	n_posix_literal( "o" ),
	n_posix_literal( "p" ),
	n_posix_literal( "q" ),
	n_posix_literal( "r" ),
	n_posix_literal( "s" ),
	n_posix_literal( "t" ),
	n_posix_literal( "u" ),
	n_posix_literal( "v" ),
	n_posix_literal( "w" ),
	n_posix_literal( "x" ),
	n_posix_literal( "y" ),
	n_posix_literal( "z" ),
	n_posix_literal( " " ),
	n_posix_literal( "Caps" ),
	n_posix_literal( "BS" )

};




// internal
n_posix_bool
n_win_inputpopup_is_error( HWND hpopup, HWND target )
{

	if ( hpopup == NULL ) { return n_posix_true; }
	if ( target == NULL ) { return n_posix_true; }

	if ( n_posix_false == IsWindow( hpopup ) ) { return n_posix_true; }
	if ( n_posix_false == IsWindow( target ) ) { return n_posix_true; }


	return n_posix_false;
}

void
n_win_inputpopup_close_send( HWND hpopup )
{

	n_win_message_send( hpopup, WM_CLOSE, 0,0 );


	return;
}

n_posix_bool
n_win_inputpopup_capslock_onoff( void )
{
	return ( GetKeyState( VK_CAPITAL ) & 0x0001 );
}

void
n_win_inputpopup_autoclose( void )
{

	// [!] : you need to call this function at WM_CLOSE


	HWND hpopup = n_win_inputpopup_hpopup;
	HWND target = n_win_inputpopup_target;


	if ( n_win_inputpopup_is_error( hpopup, target ) ) { return; }


	if ( hpopup ==            GetFocus()   ) { return; }
	if ( hpopup == GetParent( GetFocus() ) ) { return; }


	// [!] : combined version of n_win_is_hovered()

	{

		n_type_gfx fx,fy,fsx,fsy; n_win_location_relative( NULL, hpopup, &fx,&fy,&fsx,&fsy );
		n_type_gfx tx,ty,tsx,tsy; n_win_location_relative( NULL, target, &tx,&ty,&tsx,&tsy );

		n_type_gfx  x = n_posix_min_n_type_gfx(  fx,  tx );
		n_type_gfx  y = n_posix_min_n_type_gfx(  fy,  ty );
		n_type_gfx sx = n_posix_max_n_type_gfx( fsx, tsx );
		n_type_gfx sy = fsy + tsy;

		if ( n_win_is_hovered_offset( NULL, x,y,sx,sy ) ) { return; }

	}


	n_win_inputpopup_close_send( hpopup );


	return;
}

// internal
void
n_win_inputpopup_automove( HWND hpopup, HWND target )
{

	if ( n_win_inputpopup_is_error( hpopup, target ) ) { return; }


	// [!] : don't use GetClientRect() : border is needed


	n_type_gfx x,y,sx,sy;


	n_win_location_relative( NULL, target, &x, &y, NULL, &sy );

	y += sy;

	n_win_size( hpopup, &sx, &sy );


	x -= n_win_inputpopup_instance.shadow_l;

	SetWindowPos( hpopup, NULL, x,y,sx,sy, SWP_NOACTIVATE | SWP_DRAWFRAME );


	return;
}

// internal
void
n_win_inputpopup_draw_buttons( n_win_inputpopup *p )
{

	n_bmp_new_fast( &p->bmp_buttons, p->csx_all, p->csy_all );

	u32 color_inner = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	n_bmp_flush( &p->bmp_buttons, color_inner );


	n_type_gfx x = p->pad + p->shadow_l;
	n_type_gfx y = p->pad;

	int i = 0;
	while( 1 )
	{//break;

		n_bmp *bmp_t = &p->hbtn[ i ].bmp;


		n_type_gfx tmp_sx;
		if( i <= ( KEY_MAX - 3 ) )
		{
			tmp_sx = p->size;
		} else {
			tmp_sx = p->size + ( p->size / 2 );
			if ( i == ( BTN_MAX - 1 ) ) { tmp_sx += p->csx_all % 2; }
		}


		n_type_gfx bmpsx = N_BMP_SX( bmp_t );
		n_type_gfx bmpsy = N_BMP_SY( bmp_t );

		if ( NULL == N_BMP_PTR( bmp_t ) )
		{
			n_bmp_box( &p->bmp_buttons, x,y,tmp_sx,p->size, n_bmp_rgb( 0,200,255 ) );
		} else {
			n_bmp_fastcopy( bmp_t, &p->bmp_buttons, 0,0,bmpsx,bmpsy, x,y );
		}

		x += tmp_sx + p->gap;
		if ( ( i % 10 ) == 9 )
		{
			x = p->pad + p->shadow_l;

			y += p->size + p->gap;
		}


		i++;
		if ( i >= BTN_MAX ) { break; }
	}


//n_bmp_save_literal( &p->bmp_buttons, "ret.bmp" );



	return;
}

// internal
void
n_win_inputpopup_draw( n_win_inputpopup *p )
{

	if ( n_win_fluent_ui_onoff == n_posix_false ) { return; }


	n_win_size_client( p->hwnd, &p->csx, &p->csy );

	n_type_gfx sx = p->csx - ( p->shadow_l + p->shadow_r );
	n_type_gfx sy = p->csy - ( p->shadow_u + p->shadow_d );


	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, p->csx, p->csy );


	RECT r; GetWindowRect( p->hwnd, &r );
	n_type_gfx rx,ry,rsx,rsy; n_win_rect_expand_range( &r, &rx,&ry,&rsx,&rsy );

	n_bmp_fastcopy( &p->bmp_desktop, &bmp, rx,ry,p->csx,p->csy, 0,0 );


	n_type_gfx drop_onoff = ( p->shadow_l == 0 );

	n_bmp_ui_roundframe_shadow( &bmp, -1,-1, p->shadow_r, p->round, p->scale, n_win_darkmode_onoff, drop_onoff );

	n_bmp_ui_roundframe
	(
		&bmp,
		p->shadow_l, 0, sx, sy,
		p->round,
		p->scale,
		p->color_outer,
		p->color_inner
	);


	{
		n_type_gfx  fx = p->shadow_l + p->pad;
		n_type_gfx  fy = p->shadow_u + p->pad;
		n_type_gfx fsx = sx - ( p->pad * 2 );
		n_type_gfx fsy = sy - ( p->pad * 2 );
		n_type_gfx  tx = fx;
		n_type_gfx  ty = fy;
		n_type_gfx  dy = p->csy_all - p->csy;

		ty  -= dy;
		fsy += dy;

		if ( ty < fy )
		{
			n_type_gfx tmp = fy - ty;

			ty  = fy;
			fy  = fy  + tmp;
			fsy = fsy - tmp;
		}

//n_win_hwndprintf_literal( GetParent( p->hwnd ), " %d %d ", fy, ty );

		n_bmp_fastcopy( &p->bmp_buttons, &bmp, fx,fy,fsx,fsy, tx,ty );
	}


	HDC hdc = GetDC( p->hwnd );

//n_bmp_flush( &bmp, n_bmp_rgb( 0,200,255 ) );
	n_gdi_bitmap_draw_main( p->hwnd, hdc, &bmp, 0,0,p->csx,p->csy, 0,0 );

	ReleaseDC( p->hwnd, hdc );


	n_bmp_free_fast( &bmp );


	return;
}

// internal
void
n_win_inputpopup_slide( n_win_inputpopup *p )
{

	p->slide_timer_sy += p->slide_timer_step;
//n_posix_sleep( 200 );

	if ( p->slide_timer_sy >= p->csy_all )
	{

		n_type_gfx sx = p->csx_all;
		n_type_gfx sy = p->csy_all;

		n_type_gfx i = 0;
		while( 1 )
		{
			p->hbtn[ i ].hide_onoff = n_posix_false;

			i++;
			if ( i >= BTN_MAX ) { break; }
		}

		SetWindowPos( p->hwnd, NULL, 0,0,sx,sy, SWP_NOMOVE );
		n_win_inputpopup_draw( p );

		p->slide_timer_is_running = n_posix_false;

		n_win_timer_exit( p->hwnd, p->slide_timer_id );

	} else {

		n_type_gfx sx = p->csx_all;
		n_type_gfx sy = (n_type_gfx) p->slide_timer_sy;

		SetWindowPos( p->hwnd, NULL, 0,0,sx,sy, SWP_NOMOVE );
		n_win_inputpopup_draw( p );

	}


	return;
}

// internal
void
n_win_inputpopup_animatewindow_system( HWND hwnd )
{

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

	// [x] : n_AW_BLEND : draw error

	n_posix_bool onoff = n_posix_false;
	SystemParametersInfo( SPI_GETCOMBOBOXANIMATION, 0, &onoff, 0 );

	if ( onoff )
	{

		n_win_button_printclient_onoff = n_posix_true;

		int aw = n_AW_SLIDE | n_AW_VER_POSITIVE;

		// [x] : Win2000 : n_AW_SLIDE : not working : when using region
/*
		if ( n_win_fluent_ui_onoff )
		{
			if ( n_posix_false == n_sysinfo_version_xp_or_later() )
			{
				aw = n_AW_BLEND | n_AW_VER_POSITIVE;
			}
		}
*/
		n_posix_bool ret = n_win_animatewindow( hwnd, 0, aw );
		if ( ret ) { ShowWindow( hwnd, SW_NORMAL ); }

		n_win_button_printclient_onoff = n_posix_false;

	} else {

		ShowWindowAsync( hwnd, SW_SHOWNA );

	}

#else  // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

	ShowWindowAsync( hwnd, SW_SHOWNA );

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW


	return;
}

// internal
LRESULT CALLBACK
n_win_inputpopup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int keybind[] = {

		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
		'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
		'U', 'V', 'W', 'X', 'Y', 'Z',
		VK_SPACE, VK_CAPITAL, VK_BACK

	};


	n_win_inputpopup *p = &n_win_inputpopup_instance;


	static n_type_gfx border;
	static n_type_gfx ox = 0;
	static n_type_gfx oy = 0;


	n_posix_char *s;
	n_type_gfx    i, x,y;


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == p->slide_timer_id )
		{
			n_win_inputpopup_slide( p );

			ShowWindowAsync( hwnd, SW_NORMAL );
		}

	break;


	case WM_CREATE :


		// Global

		n_win_inputpopup_zero( &n_win_inputpopup_instance );

		p->hwnd = hwnd;

		if ( n_win_fluent_ui_onoff )
		{
			p->mode = N_WIN_INPUTPOPUP_MODE_ORIGINAL;
		} else {
			p->mode = N_WIN_INPUTPOPUP_MODE_SYSTEM;
		}


		n_win_stdsize( hwnd, &p->size, NULL, NULL );

		border = GetSystemMetrics( SM_CXBORDER );

		p->csx_all = ( p->size * 10 ) + ( border * 2 );
		p->csy_all = ( p->size *  4 ) + ( border * 2 );


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		// [Needed] : Win2000 : fade needs this
		DragAcceptFiles( hwnd, n_posix_true );


		n_win_topmost( hwnd, n_posix_true );


		// Style

		if ( p->mode == N_WIN_INPUTPOPUP_MODE_SYSTEM )
		{

			ox = oy = 0;//border;
			p->gap = 0;

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

			n_win_style_dropshadow_onoff( hwnd, n_posix_true );

		} else {

			n_win_style_new( hwnd, WS_POPUP );

			p->color_inner = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			p->color_outer = n_bmp_blend_pixel( p->color_inner, n_bmp_black, 0.25 );

			p->round = n_win_fluent_ui_round_param( p->hwnd );
			p->scale = (n_type_gfx) ceil( n_win_scale( hwnd ) );

			p->gap = GetSystemMetrics( SM_CXBORDER ) * p->scale;
			p->pad = p->gap * 2;

			p->csx_all += p->gap * 9;
			p->csy_all += p->gap * 3;

			p->csx_all += p->pad * p->scale;
			p->csy_all += p->pad * p->scale;

			n_win_fluent_ui_shadow_metrics
			(
				 hwnd,
				&p->shadow_u,
				&p->shadow_d,
				&p->shadow_l,
				&p->shadow_r
			);

			p->csx_all += p->shadow_l + p->shadow_r;
			p->csy_all += p->shadow_u + p->shadow_d;

			if ( p->shadow_d == 0 )
			{
				n_win_style_dropshadow_onoff( hwnd, n_posix_true );
			}

		}


		// Buttons

//n_win_hwndprintf_literal( n_win_inputpopup_target, "%x", GetKeyState( VK_CAPITAL ) );

		n_posix_bool number = n_win_property_get_literal( n_win_inputpopup_target, "Number" );
		DWORD        style  = n_win_style_get( n_win_inputpopup_target );
		n_posix_bool caps   = n_win_inputpopup_capslock_onoff();


		x = p->pad + p->shadow_l;
		y = p->pad;

		i = 0;
		while( 1 )
		{
//break;
			if ( caps )
			{
				s = n_win_inputpopup_keytable_upper[ i ];
			} else {
				s = n_win_inputpopup_keytable_lower[ i ];
			}

			n_win_button_zero( &p->hbtn[ i ] );
			n_win_button_init( &p->hbtn[ i ], hwnd, s, PBS_NORMAL );

			if ( p->mode == N_WIN_INPUTPOPUP_MODE_SYSTEM )
			{
				//
			} else {
				p->hbtn[ i ].hide_onoff       = n_posix_true;
				p->hbtn[ i ].bmp_backup_onoff = n_posix_true;
			}


			n_type_gfx tmp_sx;
			if( i <= ( KEY_MAX - 3 ) )
			{
				tmp_sx = p->size;
			} else {
				tmp_sx = p->size + ( p->size / 2 );
				if ( i == ( BTN_MAX - 1 ) ) { tmp_sx += p->csx_all % 2; }
			}

			n_win_move_simple( p->hbtn[ i ].hwnd, x,y, tmp_sx,p->size, n_posix_false );


			if (
				( ( style & ES_NUMBER )||( number ) )
				&&
				( ( i >= 10 )&&( i <= ( BTN_MAX - 2 ) ) )
			)
			{
				n_win_button_grayed_onoff_light( &p->hbtn[ i ], n_posix_true  );
			} else {
				n_win_button_grayed_onoff_light( &p->hbtn[ i ], n_posix_false );
			}


			x += tmp_sx + p->gap;
			if ( ( i % 10 ) == 9 )
			{
				x = p->pad + p->shadow_l;

				y += p->size + p->gap;
			}


			i++;
			if ( i >= BTN_MAX ) { break; }
		}


		// Display

		n_win_move_simple( hwnd, 0,0, p->csx_all,p->csy_all, n_posix_false );
		n_win_inputpopup_automove( hwnd, n_win_inputpopup_target );

//ShowWindowAsync( hwnd, SW_SHOWNA );break;

		if ( p->mode == N_WIN_INPUTPOPUP_MODE_SYSTEM )
		{

			n_win_inputpopup_animatewindow_system( hwnd );

		} else {

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETCOMBOBOXANIMATION, 0, &onoff, 0 );

			if ( onoff )
			{

				n_win_button_printclient_onoff = n_posix_true;

				i = 0;
				while( 1 )
				{//break;

					p->hbtn[ i ].hide_onoff = n_posix_false;
					n_win_button_draw( &p->hbtn[ i ], NULL, NULL );
					p->hbtn[ i ].hide_onoff = n_posix_true;

					i++;
					if ( i >= BTN_MAX ) { break; }
				}

				n_win_inputpopup_draw_buttons( p );

				n_win_button_printclient_onoff = n_posix_false;


				ShowWindow( hwnd, SW_HIDE );


				// [!] : Win32 minimal : 10 msec.

				n_type_gfx slide_msec = 10;

				p->slide_timer_sy   = 0;
				p->slide_timer_unit = N_BMP_FADE_MSEC;
				p->slide_timer_step = (double) p->csy_all / p->slide_timer_unit * slide_msec;
				p->slide_timer_tick = n_posix_tickcount();


				n_win_fluent_ui_bmp_desktop( hwnd, &p->bmp_desktop );


				p->slide_timer_is_running = n_posix_true;
				n_win_timer_init( hwnd, p->slide_timer_id, slide_msec );

			} else {

				n_win_inputpopup_animatewindow_system( hwnd );

			}

		}

	break;


	case WM_MOUSEACTIVATE :
//n_posix_debug_literal( " ! " );

		return MA_NOACTIVATE;//MA_NOACTIVATEANDEAT;

	break;


	case WM_COMMAND :

		i = 0;
		while( 1 )
		{//break;

			if ( (HWND) lparam == p->hbtn[ i ].hwnd )
			{

				if ( n_win_inputpopup_target != GetFocus() )
				{
					SetFocus( n_win_inputpopup_target );
				}

				n_win_input( 0, keybind[ i ] );


				break;
			}

			i++;
			if ( i >= BTN_MAX ) { break; }
		}

		//return 0;

	break;


	case WM_KILLFOCUS :

		n_win_inputpopup_autoclose();

	break;


	case WM_CLOSE :
	{

		if ( n_win_inputpopup_silent_onoff == n_posix_false )
		{

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETMENUFADE, 0, &onoff, 0 );

			if ( onoff )
			{
				int aw = n_AW_HIDE | n_AW_BLEND | n_AW_VER_NEGATIVE;
				n_win_animatewindow( hwnd, 0, aw );
			}

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

		} else {

			n_win_inputpopup_silent_onoff = n_posix_false;

		}


		if ( n_win_inputpopup_txtbox != NULL )
		{
			n_win_inputpopup_txtbox_prv = n_win_inputpopup_txtbox;
			n_win_txtbox_on_focus( n_win_inputpopup_txtbox, n_posix_false );
		}


		n_win_inputpopup_hpopup = NULL;
		n_win_inputpopup_target = NULL;
		n_win_inputpopup_txtbox = NULL;


		int i = 0;
		while( 1 )
		{

			n_win_button_exit( &p->hbtn[ i ] );

			i++;
			if ( i >= BTN_MAX ) { break; }
		}


		n_bmp_free_fast( &p->bmp_desktop );
		n_bmp_free_fast( &p->bmp_buttons );


		n_win_inputpopup_zero( &n_win_inputpopup_instance );


		DestroyWindow( hwnd );

	}
	break;	


	} // switch


	i = 0;
	while( 1 )
	{//break;

		n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn[ i ] );

		i++;
		if ( i >= BTN_MAX ) { break; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_win_inputpopup_open( HWND hwnd_parent, HWND hwnd_target )
{

	if ( hwnd_target != n_win_inputpopup_target )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	if ( n_win_inputpopup_hpopup == NULL )
	{
		n_win_inputpopup_target = hwnd_target;
		n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_inputpopup_wndproc, &n_win_inputpopup_hpopup );

		if ( n_win_inputpopup_target != GetFocus() ) { SetFocus( hwnd_target ); }
	}

	return;
}

void
n_win_inputpopup_open_txtbox( HWND hwnd_parent, n_win_txtbox *txtbox_target )
{

	if ( txtbox_target->hwnd != n_win_inputpopup_target )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	if ( n_win_inputpopup_hpopup == NULL )
	{
		if ( txtbox_target->focus_fade_is_running ) { return; }

		n_win_inputpopup_target = txtbox_target->hwnd;
		n_win_inputpopup_txtbox = txtbox_target;
		n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_inputpopup_wndproc, &n_win_inputpopup_hpopup );

		if ( n_win_inputpopup_target != GetFocus() )
		{
			SetFocus( n_win_inputpopup_target );
		}

		n_win_txtbox_on_focus( n_win_inputpopup_txtbox, n_posix_true );
	}

	return;
}

void
n_win_inputpopup_close( void )
{

	if ( n_win_inputpopup_hpopup != NULL )
	{
		n_win_inputpopup_autoclose();
	}

	return;
}

void
n_win_inputpopup_close_forced( void )
{

	if ( n_win_inputpopup_hpopup != NULL )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	return;
}

void
n_win_inputpopup_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND target )
{

	n_win_inputpopup *p = &n_win_inputpopup_instance;


	switch( msg ) {


	case WM_COMMAND :

		if ( target != (HWND) lparam )
		{

			if ( n_posix_false == IsWindow( n_win_inputpopup_hpopup ) ) { break; }

			if ( n_win_class_is_same_literal( (HWND) lparam, "Edit" ) ) { break; }

			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );

		} else
		if ( EN_SETFOCUS == HIWORD( wparam ) )
		{

			n_win_inputpopup_open( hwnd, target );

		} else
		if ( EN_KILLFOCUS == HIWORD( wparam ) )
		{

			n_win_inputpopup_close();

		}// else

	break;


	case WM_MOVE :

		if ( n_win_inputpopup_hpopup != NULL )
		{
			n_win_inputpopup_silent_onoff = n_posix_true;
			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
			break;
		}

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;

	case WM_SIZE :
	//case WM_MOUSEMOVE   :
	//case WM_NCMOUSEMOVE :

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;


	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
//n_posix_debug_literal( "" );

		if ( n_win_inputpopup_is_error( n_win_inputpopup_hpopup, n_win_inputpopup_target ) ) { break; }

		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );

	break;


	case WM_KEYDOWN :

		if ( (int) wparam == VK_CAPITAL )
		{

			n_posix_bool caps = n_win_inputpopup_capslock_onoff();

			int i = 0;
			while( 1 )
			{

				n_posix_char *s;

				if ( caps )
				{
					s = n_win_inputpopup_keytable_upper[ i ];
				} else {
					s = n_win_inputpopup_keytable_lower[ i ];
				}

				n_win_hwndprintf_literal( p->hbtn[ i ].hwnd, "%s", s );

				i++;
				if ( i >= BTN_MAX ) { break; }
			}

		}

	break;


	case WM_CLOSE :

		// [x] : prevent GDI handle leak : closed when hpopup is ON
		//
		//	you need to send WM_CLOSE manually

	break;


	} // switch


	return;
}

void
n_win_inputpopup_proc_light( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND target )
{

	n_win_inputpopup *p = &n_win_inputpopup_instance;


	switch( msg ) {


	case WM_MOVE :

		if ( n_win_inputpopup_hpopup != NULL )
		{
			n_win_inputpopup_silent_onoff = n_posix_true;
			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
			break;
		}

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;

	case WM_SIZE :
	//case WM_MOUSEMOVE   :
	//case WM_NCMOUSEMOVE :

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;


	case WM_NCLBUTTONUP :
	case WM_NCMBUTTONUP :
	case WM_NCRBUTTONUP :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :

		if ( n_win_inputpopup_target != n_win_cursor2hwnd_relative( hwnd ) )
		{
			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
		}

	break;


	case WM_KEYDOWN :

		if ( (int) wparam == VK_CAPITAL )
		{

			n_posix_bool caps = n_win_inputpopup_capslock_onoff();

			int i = 0;
			while( 1 )
			{

				n_posix_char *s;

				if ( caps )
				{
					s = n_win_inputpopup_keytable_upper[ i ];
				} else {
					s = n_win_inputpopup_keytable_lower[ i ];
				}

				n_win_hwndprintf_literal( p->hbtn[ i ].hwnd, "%s", s );

				i++;
				if ( i >= BTN_MAX ) { break; }
			}

		}

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %x %x %x ", lparam, hwnd, n_win_hwnd_toplevel( hwnd ) );

			if ( (HWND) lparam == NULL )
			{
				n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
			}

		}

	break;


	} // switch


	return;
}

void
n_win_inputpopup_patch( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam )
{

	HWND hpopup = n_win_inputpopup_hpopup;


	// [!] : suppress gray-out when "hpopup" is active

	switch( msg ) {

	case WM_NCACTIVATE :

		if ( (*wparam) == n_posix_false )
		{
			(*wparam) = IsWindow( hpopup );
		}

	break;

	} // switch


	// [!] : restoring is needed when "hpopup" is closed

	static n_posix_bool onoff = n_posix_false;

	if ( IsWindow( hpopup ) )
	{

		onoff = n_posix_true;

	} else
	if ( onoff )
	{

		onoff = n_posix_false;


		HWND         h       = n_win_cursor2hwnd();
		n_posix_bool restore = n_posix_false;


		if (
			( hwnd == h )
			||
			( IsChild(   hwnd, h ) )
			||
			( IsChild( hpopup, h ) )
		)
		{
			restore = n_posix_true;
		}


		n_win_message_send( hwnd, WM_NCACTIVATE, restore, 0 );


		// [!] : Win95 : hangup
		//
		//	don't use SetActiveWindow( hwnd );

		if ( restore ) { SetFocus( n_win_cursor2hwnd() ); }

	}


	return;
}


#undef KEY_MAX
#undef BTN_MAX


#endif // _H_NONNON_WIN32_WIN_INPUTPOPUP


// Watchcat Process Enumerator
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_PROCESSLIST
#define _H_NONNON_WIN32_SYSINFO_PROCESSLIST




#include "../../neutral/vector.c"


#include "./process.c"




typedef struct {

	n_vector exe;
	n_vector pid;
	n_vector hwnd;

} n_sysinfo_processlist;




void
n_sysinfo_processlist_zero( n_sysinfo_processlist *p )
{

	if ( p == NULL ) { return; }


	n_vector_zero( &p->exe  );
	n_vector_zero( &p->pid  );
	n_vector_zero( &p->hwnd );


	return;
}

void
n_sysinfo_processlist_exit( n_sysinfo_processlist *p )
{

	if ( p == NULL ) { return; }


	n_vector_free( &p->exe  );
	n_vector_free( &p->pid  );
	n_vector_free( &p->hwnd );


	return;
}

void
n_sysinfo_processlist_init( n_sysinfo_processlist *p )
{

	if ( p == NULL ) { return; }


	n_vector_new( &p->exe  );
	n_vector_new( &p->pid  );
	n_vector_new( &p->hwnd );


	return;
}

void
n_sysinfo_processlist_copy( n_sysinfo_processlist *f, n_type_int index_f, n_sysinfo_processlist *t, n_type_int index_t )
{

	if ( f == NULL ) { return; }
	if ( f == NULL ) { return; }


	n_vector_add( &t->exe,  index_t, n_vector_get( &f->exe,  index_f ) );
	n_vector_add( &t->pid,  index_t, n_vector_get( &f->pid,  index_f ) );
	n_vector_add( &t->hwnd, index_t, n_vector_get( &f->hwnd, index_f ) );


	return;
}

void
n_sysinfo_processlist_del( n_sysinfo_processlist *p, n_type_int y )
{

	if ( p == NULL ) { return; }


	n_vector_del( &p->exe,  y );
	n_vector_del( &p->pid,  y );
	n_vector_del( &p->hwnd, y );


	return;
}

n_posix_bool
n_sysinfo_processlist_is_same( n_sysinfo_processlist *a, n_type_int a_index, n_sysinfo_processlist *b, n_type_int b_index )
{

	if (
		( n_string_is_same( a->exe .line[ a_index ], b->exe .line[ b_index ] ) )
		&&
		( n_string_is_same( a->pid .line[ a_index ], b->pid .line[ b_index ] ) )
		&&
		( n_string_is_same( a->hwnd.line[ a_index ], b->hwnd.line[ b_index ] ) )
	)
	{
		return n_posix_true;
	}


	return n_posix_false;
}

static n_sysinfo_processlist *n_sysinfo_processlist_make_target = NULL;

BOOL CALLBACK
n_sysinfo_processlist_make_enumwindows( HWND hwnd, LPARAM lparam )
{

	n_sysinfo_process *p = (void*) lparam;


	n_posix_char str[ 100 ];


	n_vector_set( &n_sysinfo_processlist_make_target->exe, 0, p->name );
	n_string_free( p->name );


	n_posix_sprintf_literal( str, "%08d", (int) p->pid );
	n_vector_set( &n_sysinfo_processlist_make_target->pid, 0, str );


	n_posix_sprintf_literal( str, "%08d", (int) hwnd );
	n_vector_set( &n_sysinfo_processlist_make_target->hwnd, 0, str );


	return n_posix_true;
}

void
n_sysinfo_processlist_make( n_sysinfo_processlist *p )
{

	n_sysinfo_processlist_init( p );

	n_sysinfo_processlist_make_target = p;
	n_sysinfo_process_main( n_sysinfo_processlist_make_enumwindows );


	return;
}

#define n_sysinfo_processlist_format_cch( p, i ) n_sysinfo_processlist_format( p, i, NULL )

n_type_int
n_sysinfo_processlist_format( n_sysinfo_processlist *p, n_type_int i, n_posix_char *str_ret )
{

	n_posix_char *pid = (n_posix_char*) p->pid.line[ i ];
	n_posix_char *exe = (n_posix_char*) p->exe.line[ i ];

	n_type_int cch_ret = 0;

	if (
		( n_posix_false == n_string_is_empty( pid ) )
		&&
		( n_posix_false == n_string_is_empty( exe ) )
	)
	{
		if ( str_ret != NULL )
		{
			cch_ret = n_posix_sprintf_literal( str_ret, " %s : %s", pid, exe );
		} else {
			cch_ret = 1 + n_posix_strlen( pid ) + 3 + n_posix_strlen( exe );
		}
	} else {
		if ( str_ret != NULL )
		{
			n_string_truncate( str_ret );
		}
	}


	return cch_ret;
}

HWND
n_sysinfo_processlist_pid2hwnd( n_sysinfo_processlist *p, DWORD pid )
{

	HWND ret = NULL;


	n_type_int i = 0;
	while( 1 )
	{

		if ( pid == (DWORD) n_posix_atoi( p->pid.line[ i ] ) )
		{

			ret = (HWND) n_posix_atoi( p->hwnd.line[ i ] );

			break;
		}


		i++;
		if ( i >= p->exe.sy ) { break; }
	}


	return ret;
}


#endif // _H_NONNON_WIN32_SYSINFO_PROCESSLIST


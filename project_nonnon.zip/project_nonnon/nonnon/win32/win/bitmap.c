// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_BITMAP
#define _H_NONNON_WIN32_WIN_BITMAP




#include "./_debug.c"
#include "./message.c"




#define n_win_bitmap_exit( hbmp ) DeleteObject( hbmp )

#define n_win_bitmap_init_literal( name ) n_win_bitmap_init( n_posix_literal( name ) )

HBITMAP
n_win_bitmap_init( const n_posix_char *name )
{

	// [!] : load from file : n_win_bitmap_exit() is needed


	return LoadImage( GetModuleHandle( NULL ), name, IMAGE_BITMAP, 0,0, LR_LOADFROMFILE );
}

HBITMAP
n_win_bitmap_get( HWND hgui )
{

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		return (HBITMAP) n_win_message_send( hgui, STM_GETIMAGE, IMAGE_BITMAP, 0 );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		return (HBITMAP) n_win_message_send( hgui, BM_GETIMAGE, IMAGE_BITMAP, 0 );
	}


	return NULL;
}

void
n_win_bitmap_set( HWND hgui, HBITMAP hbmp )
{

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		n_win_bitmap_exit( (HBITMAP) n_win_message_send( hgui, STM_GETIMAGE, IMAGE_BITMAP, 0 ) );
		n_win_message_send( hgui, STM_SETIMAGE, IMAGE_BITMAP, hbmp );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		n_win_bitmap_exit( (HBITMAP) n_win_message_send( hgui, BM_GETIMAGE, IMAGE_BITMAP, 0 ) );
		n_win_message_send( hgui, BM_SETIMAGE, IMAGE_BITMAP, hbmp );
	}


	return;
}

#define n_win_bitmap_add(         h, s ) n_win_bitmap_set( h, n_win_bitmap_init(         s ) )
#define n_win_bitmap_add_literal( h, s ) n_win_bitmap_set( h, n_win_bitmap_init_literal( s ) )
#define n_win_bitmap_del(         h    ) n_win_bitmap_exit( n_win_bitmap_get( h ) )


#endif // _H_NONNON_WIN32_WIN_BITMAP


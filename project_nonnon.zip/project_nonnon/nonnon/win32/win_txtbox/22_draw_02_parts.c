// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_draw_border( n_win_txtbox *p, HDC hdc, COLORREF color, n_posix_bool is_flat )
{
//return;
//n_win_txtbox_debug_count( p );


	n_type_gfx sx = p->client_pxl_sx;
	n_type_gfx sy = p->client_pxl_sy;

	n_type_gfx i = 0;
	while( 1 )
	{

		n_win_frame( hdc, i,i,sx-(i*2),sy-(i*2), color );

		i++;
		if ( i >= p->scale ) { break; }
	}

	if ( is_flat ) { return; }

	while( 1 )
	{//break;


		n_win_frame( hdc, i,i,sx-(i*2),sy-(i*2), p->color_back__enabled );

		i++;
		if ( i >= ( p->scale * 2 ) ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_draw_eol( n_win_txtbox *p, HDC hdc, n_type_int x, n_type_int y, u32 bg, n_posix_char *eol )
{

	if ( p == NULL ) { return; }


	SetBkColor  ( hdc, bg );
	SetTextColor( hdc, p->color_text_eol_mark );

	SIZE size = n_win_txtbox_size_text_fast( p, hdc, eol );
	RECT rect = n_win_rect_set( NULL, (int) x, (int) y, size.cx, size.cy );

	n_win_txtbox_draw_text( p, hdc, eol, -1, &rect, p->drawtext_modes );

	p->eol_rect = rect;


	return;
}

// internal
void
n_win_txtbox_draw_caret( n_win_txtbox *p, HDC hdc, n_bmp *bmp )
{

	// [!] : fake caret

	// [x] : system caret is buggy
	//
	//	interfere with other edit controls' caret


	if ( p == NULL ) { return; }


	n_type_gfx  x = p->caret_pxl_x;
	n_type_gfx  y = p->caret_pxl_y;
	n_type_gfx sx = p->caret_pxl_sx;
	n_type_gfx sy = p->caret_pxl_sy;

	// [!] : don't include padding
	n_type_gfx fx = p->border_pxl_sx;
	n_type_gfx tx = p->canvas_pxl_sx - p->border_pxl_sx - p->smallbutton_margin;

	if ( p->number_pxl_sx != 0 ) { fx += p->pad_pxl_sx + p->number_pxl_sx; }

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d : %d ", x, y, sx, sy, fx, tx );


	// [!] : Win9x/NT4        : "sx" is 2px
	// [!] : Win2000 or later : "sx" is 1px by default (you can change this)

	if ( p->is_2k_or_later )
	{
		if ( ( p->ime_onoff )&&( sx == 1 ) ) { sx = 2; }
	} else {
		//
	}


	{

		n_posix_bool draw = n_posix_true;

		if ( p->hwnd != GetFocus() )
		{

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET )
			{
				draw = n_posix_false;
			}

			n_win_txtbox_caret_reset( p, n_posix_true );

		} else {

			if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ) )
			{

				// [!] : fade-in -> stay for a while -> fade-out

				if ( p->caret_fade_in )
				{
					p->caret_blend += 0.1;
					if ( p->caret_blend >=  2.0 ) { p->caret_blend = 2.0; p->caret_fade_in = n_posix_false; }
				} else {
					p->caret_blend -= 0.1;
					if ( p->caret_blend <= -1.0 ) { p->caret_blend = 0.0; p->caret_fade_in = n_posix_true ; }
				}

			} else {
//static int i = 0;
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %f ", i, p->caret_fade_in, p->caret_blend );
//i++;
				// [!] : fade-in -> stay for a while -> fade-out

				if ( p->caret_fade_in )
				{
					p->caret_blend = 1.0;
					p->caret_fade_in = n_posix_false;
				} else {
					p->caret_blend = 0.0;
					p->caret_fade_in = n_posix_true ;
				}

			}

			// [Needed] : Vista : fast blinking problem
			if ( p->is_dragging )
			{
				p->caret_blend = 1.0;
				p->caret_fade_in = n_posix_false;
			}

		}


		p->ime_outbound = N_WIN_TXTBOX_CARET_OUTBOUND_NONE;

		n_type_gfx outbound_fx = fx + p->size_fullwidth.cx;
		n_type_gfx outbound_tx = tx - p->size_fullwidth.cx;

		if ( x < outbound_fx ) { p->ime_outbound = N_WIN_TXTBOX_CARET_OUTBOUND_LEFT ; }
		if ( x > outbound_tx ) { p->ime_outbound = N_WIN_TXTBOX_CARET_OUTBOUND_RIGHT; }

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			if ( p->ime_composition_onoff ) { draw = n_posix_false; }
		}

		if ( x < fx ) { draw = n_posix_false; }
		if ( x > tx ) { draw = n_posix_false; }

//draw = n_posix_false;
		if ( draw )
		{

			double blend = p->caret_blend;
			if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ) )
			{
				if ( blend > 1.0 ) { blend = 1.0; }
				if ( blend < 0.0 ) { blend = 0.0; }
			}

			if ( p->hwnd != GetFocus() ) { blend = 0.25; }

			if ( p->caret_blend_override_onoff ) { blend = p->caret_blend_override_value; }

			n_win_txtbox_draw_box_invert( p, bmp, x,y,sx,sy, blend );

			ExcludeClipRect( hdc, x, y, x + sx, y + sy );

		}


	}


	// [!] : remember the last position

	p->ime_prv = p->ime;

	POINT pt = { x, y }; p->ime = pt;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->scale, y );

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		p->ime.y += p->scale;
	}


	return;
}

// internal
void
n_win_txtbox_draw_linenumber
(
	n_win_txtbox *p,
	         HDC  hdc,
	  n_type_int  text_y,
	  n_type_gfx   x,
	  n_type_gfx   y,
	  n_type_gfx  sx,
	  n_type_gfx  sy,
	n_posix_bool  is_underline,
	       HFONT  hf_noline
)
{

	if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx, y, p->number_pxl_sx, sy );

	if ( text_y < p->txt.sy )
	{
		n_type_int cch_y = text_y;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX )
		{
			//
		} else {
			cch_y++;
		}

		n_posix_bool over_ten_thousand = n_posix_false;
		if ( cch_y >= 10000 ) { over_ten_thousand = n_posix_true; }

		if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

		n_posix_char str[ 6 + 1 ];

		// [Patch] : not working accurately

		if ( cch_y < 1000 )
		{
			if ( over_ten_thousand )
			{
				n_posix_sprintf_literal( str, " %04d ", (int) cch_y );
			} else {
				n_posix_sprintf_literal( str, " % 4d ", (int) cch_y );
			}
		} else {
			n_posix_sprintf_literal( str, " %d "  , (int) cch_y );
		}

		COLORREF bg = p->color_back_linenum1;
		COLORREF fg = p->color_text_linenum1;

//if ( text_y == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy );

		n_posix_bool is_curline = n_posix_false;

		if (
			( ( p->partial_selection_from_onoff )&&( text_y == ( p->select_cch_y + p->select_cch_sy - 1 ) ) )
			||
			( ( p->partial_selection_to___onoff )&&( text_y ==   p->select_cch_y                          ) )
			||
			(
				( ( p->partial_selection_from_onoff == n_posix_false )&&( p->partial_selection_to___onoff == n_posix_false ) )
				&&
				( text_y == p->select_cch_y )
			)
		)
		{
			is_curline = n_posix_true;
			bg = p->color_back_linenum2;
		}

		n_posix_bool is_sel_line = n_posix_false;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->empty_line_selection, p->select_cch_y );

		if (
			(
				( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
				&&
				( p->empty_line_selection == p->select_cch_y )
				&&
				( text_y == p->select_cch_y )
			)
			||
			(
				(                1 != p->txt.sy )
				&&
				( p->select_cch_sy == p->txt.sy )
			)
			||
			( ( p->partial_selection_from_onoff )&&( text_y == p->select_cch_y ) )
			||
			( ( p->partial_selection_to___onoff )&&( text_y == p->select_cch_y ) )
			||
			( ( p->select_cch_sx != 0 )&&( text_y == p->select_cch_y ) )
			||
			( n_win_txtbox_is_highlighted( p, N_WIN_TXTBOX_NOT_SELECTED, text_y ) )
		)
		{
			is_sel_line = n_posix_true;
			bg = p->color_back_linenum2;
		}

		n_win_txtbox_draw_box( p, hdc, &rect, bg );


		HFONT hf = SelectObject( hdc, hf_noline );

		n_type_gfx offset = p->number_pxl_sx / 6;

		int i = 5;
		while( 1 )
		{

			RECT rect_one = n_win_rect_set( NULL, p->pad_pxl_sx + ( offset * i ), y, offset, sy );

			n_posix_char str_number[ 2 ] = { str[ i ], N_STRING_CHAR_NUL };

			if ( ( is_curline )||( is_sel_line ) )
			{

				RECT r = rect_one; n_win_rect_move( &r, 1, 1 );
				SetTextColor( hdc, p->color_back_noselect );
				n_win_txtbox_draw_text( p, hdc, str_number, 1, &r, p->drawtext_modes | DT_CENTER );

				fg = p->color_text_linenum2;

				SetTextColor( hdc, fg );

				n_win_txtbox_draw_text( p, hdc, str_number, 1, &rect_one, p->drawtext_modes | DT_CENTER );

			} else {

				n_type_gfx sx = N_BMP_SX( &p->bmp_linenumber[ 0 ] );
				n_type_gfx sy = N_BMP_SY( &p->bmp_linenumber[ 0 ] );
				n_type_gfx tx = rect_one.left;
				n_type_gfx ty = rect_one.top;

				int index = str[ i ] - n_posix_literal( '0' );

				n_bmp_fastcopy( &p->bmp_linenumber[ index ], &p->bmp, 0,0,sx,sy, tx,ty );

			}

			i--;
			if ( i < 0 ) { break; }
		}

		SelectObject( hdc, hf );


		if ( is_underline )
		{
			n_type_gfx m = (n_type_gfx) trunc( n_win_scale( p->hwnd ) );
			RECT       r = n_win_rect_set( NULL, p->pad_pxl_sx, y + sy - m, p->number_pxl_sx, m );

			n_win_txtbox_draw_box( p, hdc, &r, p->color_text_linenum2 );
		}


		if ( is_sel_line )
		{
			n_type_gfx   fx = p->pad_pxl_sx + p->number_pxl_sx - ( p->number_pad_pxl_sx / 2 );
			RECT       rect = n_win_rect_set( NULL, fx, y, p->number_pad_pxl_sx, sy );

			n_win_txtbox_draw_box( p, hdc, &rect, p->color_back_linenum3 );
		}

	} else {

		rect.right++;
		n_win_txtbox_draw_box( p, hdc, &rect, p->color_back_linenum1 );

	}

	// [Needed] : padding between line number and text
	{
		COLORREF color = p->color_back_noselect;
		if ( p->debug_onoff ) { color = RGB( 0,255,0 ); }

		RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + p->number_pxl_sx, y, p->pad_pxl_sx, sy );
		n_win_txtbox_draw_box( p, hdc, &rect, color );
	}


	return;
}

void
n_win_txtbox_draw_background
(
	n_win_txtbox *p,
	         HDC  hdc,
	  n_type_int  text_y,
	  n_type_gfx  x,
	  n_type_gfx  y,
	  n_type_gfx  sx,
	  n_type_gfx  sy,
	    COLORREF *ret_bg,
	n_posix_bool  bg_input,
	n_posix_bool  is_main
)
{

	// [!] : Stripe Background

	COLORREF bg;

	if ( bg_input )
	{
		bg = (*ret_bg);
	} else {
		bg = p->color_back_noselect;

		if ( p->style & N_WIN_TXTBOX_STYLE_STRIPED )
		{
			if ( text_y & 1 ) { bg = p->color_back_striping; }
		}
	}
//bg = RGB( 200,200,200 );

	p->color_text_backgrnd = bg;

	if ( ret_bg != NULL ) { (*ret_bg) = bg; }


	COLORREF color;
	if (
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
		&&
		( n_win_txtbox_is_highlighted( p, 0, text_y ) )
	)
	{
		color = p->color_back_selected;
//n_win_txtbox_hwndprintf_literal( p, " %d ", text_y );
	} else {
		color = bg;
		if ( p->debug_onoff ) { color = RGB( 222,222,255 ); }
	}
//if ( color ) {}

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{ 
		color = 0;
	}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", y, sy, p->client_pxl_sy );


	if (
//(0)&&
		( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
	)
	{
//n_win_txtbox_debug_count( p );

		n_type_gfx nc_sx = ( p->border_pxl_sx + p->pad_pxl_sx ) * 2;
		n_type_gfx scrsx = 0; if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scrsx = p->scrollbar_pxl_sx; }

		sx = n_posix_min( sx, p->client_pxl_sx - scrsx - nc_sx );

		x += p->shadow_l;

		RECT rect = n_win_rect_set( NULL, x, y, sx, sy );
		n_win_txtbox_draw_box( p, hdc, &rect, color );

	} else
	if (
//(0)&&
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
		&&
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	)
	{

		n_type_gfx nc_sx = ( p->border_pxl_sx + p->pad_pxl_sx ) * 2;
		n_type_gfx scrsx = 0; if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scrsx = p->scrollbar_pxl_sx; }

		sx = n_posix_min( sx, p->client_pxl_sx - scrsx - nc_sx );

		RECT rect = n_win_rect_set( NULL, x, y, sx, sy );
		n_win_txtbox_draw_box( p, hdc, &rect, color );

	} else
	if (
//(0)&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		(
			( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
			||
			( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
		)
		&&
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	)
	{

		u32 clr = n_bmp_colorref2argb( color );

		n_type_gfx tx,ty,tsx,tsy;

		tx  = p->scale;
		ty  = p->scale;
		tsx = N_BMP_SX( &p->bmp ) - ( tx * 2 );
		tsy = N_BMP_SY( &p->bmp ) - ( ty * 2 );

//color = n_bmp_rgb( 0,200,255 );

		if ( p->aero_combo_onoff )
		{

			if( p->aero_combo_focus_only )
			{
				if ( p->aero_combo_init == n_posix_false )
				{
					//
				} else
				if ( p->aero_combo_fade_in )
				{
					p->selected_border_onoff = n_posix_true;
				} else {
					p->selected_border_onoff = n_posix_false;
				}

				n_bmp_roundrect_pixel( &p->bmp, tx, ty, tsx, tsy, clr, p->roundrect_pxl );
			} else {
				double ratio = 0.0;

				if ( p->aero_combo_init == n_posix_false )
				{
					//
				} else
				if ( p->aero_combo_fade_in )
				{
					ratio =         p->aero_combo_fade.percent   * 0.01;// * 0.25;
				} else {
					ratio = ( 100 - p->aero_combo_fade.percent ) * 0.01;// * 0.25;
				}

				u32 c0 = clr;
				u32 c1 = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNSHADOW );
				u32 c2 = n_bmp_rgb( 167,217,245 );//n_win_darkmode_systemcolor_colorref2argb( COLOR_HIGHLIGHT );
				u32 c3 = n_bmp_blend_pixel( c0, c1, 0.250 );
				u32 c4 = n_bmp_blend_pixel( c3, c2, ratio );
				u32 c5 = n_bmp_rgb( 232,245,252 );

				n_bmp_roundrect_pixel( &p->bmp, tx, ty, tsx, tsy, c5, p->roundrect_pxl );

				tx  += p->scale;
				ty  += p->scale;
				tsx -= p->scale * 2;
				tsy -= p->scale * 2;

				n_bmp_roundrect_pixel( &p->bmp, tx, ty, tsx, tsy, c4, p->roundrect_pxl );

				n_type_gfx  x = 0;
				n_type_gfx  y = 0;
				n_type_gfx sx = p->client_pxl_sx;
				n_type_gfx sy = p->client_pxl_sy / 2;

				n_bmp_mixer( &p->bmp, x,y,sx,sy, n_bmp_white, 0.66 );
			}

		} else {
			n_bmp_roundrect_pixel( &p->bmp, tx, ty, tsx, tsy, clr, p->roundrect_pxl );
		}

	} else {

		n_type_gfx nc_sx = ( p->border_pxl_sx + p->pad_pxl_sx ) * 2;

		sx = n_posix_min( sx, p->client_pxl_sx - nc_sx );

		n_type_gfx eol_sx = 0; n_win_rect_expand_size( &p->eol_rect, NULL,NULL,&eol_sx,NULL );

		RECT rect = n_win_rect_set( NULL, x, y, sx + eol_sx, sy );
		n_win_txtbox_draw_box( p, hdc, &rect, color );

	}


	return;
}

// internal
void
n_win_txtbox_draw_frame
(
	n_win_txtbox *p,
	         HDC  hdc,
	n_posix_bool  border_onoff
)
{
//return;

	if ( p == NULL ) { return; }


	COLORREF color_border       = p->color_base__padding;
	COLORREF color_border_mask  = p->color_base__padding;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		color_border       = 0;
		color_border_mask  = 0;
	}


	// Border

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->client_pxl_sx,p->client_pxl_sy );

	if (
//(0)&&
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
		&&
		( border_onoff )
	)
	{

		RECT r = n_win_rect_set( NULL, 0,0,p->client_pxl_sx,p->client_pxl_sy );

		// [!] : WS_EX_CLIENTEDGE causes flickering

		n_posix_bool is_selected = p->selected_border_onoff;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
		{
			is_selected = n_posix_false;
		}

		n_type_gfx bx = p->scale;//p->border_pxl_sx;
		n_type_gfx by = p->scale;//p->border_pxl_sy;

		if ( is_selected )
		{

			if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
			{
				n_win_txtbox_draw_roundframe_combo( p, p->color_border__focus );
			} else
			if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
			{
				// [x] : fast code conflicts : UxTheme overwrite all area
				n_win_txtbox_draw_roundframe( p, bx,by, p->color_border__focus );
			} else
			if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
			{
				n_win_txtbox_draw_roundframe( p, bx*2,by*2, p->color_border__focus );
			} else
			if ( n_win_darkmode_onoff )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border__focus, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border__focus, n_posix_true );
			} else {
				DrawEdge( hdc, &r, EDGE_SUNKEN, BF_RECT );
			}

		} else {

			if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
			{
				n_win_txtbox_draw_roundframe_combo( p, p->color_border___flat );
			} else
			if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
			{
				// [x] : fast code conflicts : UxTheme overwrite all area
				n_win_txtbox_draw_roundframe( p, bx,by, p->color_border___flat );
			} else
			if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
			{
				n_win_txtbox_draw_roundframe( p, bx,by, p->color_border___flat );
			} else
			if ( n_win_darkmode_onoff )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_false );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				n_win_txtbox_draw_border( p, hdc, n_bmp_white, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_false );
			} else {
				DrawEdge( hdc, &r, EDGE_SUNKEN, BF_RECT );
			}

		}

		if ( p->debug_onoff )
		{
			n_win_txtbox_draw_box( p, hdc, &r, color_border );
		}

	}

	// Mask Border

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		// [Needed] : for text clipping

		n_type_gfx bx = p->border_pxl_sx;
		n_type_gfx by = p->border_pxl_sy;
		n_type_gfx  x = 0;
		n_type_gfx  y = 0;
		n_type_gfx sx = p->client_pxl_sx;
		n_type_gfx sy = p->client_pxl_sy;
		n_type_gfx ox = sx - bx;
		n_type_gfx oy = sy - by;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sx, sy );

		ExcludeClipRect( hdc,  x,  y,      sx,      by );
		ExcludeClipRect( hdc,  x, oy,      sx, oy + by );
		ExcludeClipRect( hdc,  x,  y,      bx,      sy );
		ExcludeClipRect( hdc, ox,  y, ox + bx,      sy );

	}


	return;
}

// internal
void
n_win_txtbox_draw_scrollbars( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }


	if ( p->ime_composition_onoff )
	{

		n_win_scrollbar_enable( &p->hscr, n_posix_false, n_posix_true );
		n_win_scrollbar_enable( &p->vscr, n_posix_false, n_posix_true );

		return;
	}


	// Scrollbars

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{

		// Horizontal / X

		n_type_gfx sx = p->client_pxl_sx;
		n_type_gfx sy = p->scrollbar_pxl_sy;
		n_type_gfx  x = 0;
		n_type_gfx  y = p->client_pxl_sy - p->scrollbar_pxl_sy - p->offset_pxl_y;

		x  += p->border_pxl_sx;
		y  -= p->border_pxl_sy;
		sx -= p->border_pxl_sx * 2;
		//sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx; }


		n_posix_bool onoff;

		if ( p->is_font_monospace )
		{
			onoff = ( ( p->page_pxl_tabbed_sx / p->font_pxl_sx ) < p->txt.sx );
		} else {
			SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->txt_maxwidth_y ) );
			onoff = ( p->page_pxl_tabbed_sx < size.cx );
		}

		if ( onoff )
		{
			double pos  = (double) p->scroll_pxl_tabbed_x;
			double page = (double) p->  page_pxl_tabbed_sx;
			double max  = (double) p->  last_pxl_tabbed_sx;

			n_win_scrollbar_parameter( &p->hscr, p->font_pxl_sx, page, max, pos, n_posix_false );
		} else {
			p->scroll_pxl_tabbed_x = 0;
		}


		// [x] : off for round rect
		//n_bmp_box( &p->bmp, x,y,sx,sy, n_bmp_colorref2argb( p->color_back_noselect ) );

		n_win_scrollbar_move  ( &p->hscr, x,y,sx,sy, n_posix_true );
		n_win_scrollbar_enable( &p->hscr,     onoff, n_posix_true );

	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		// Vertical / Y

		n_type_gfx sx = p->scrollbar_pxl_sx;
		n_type_gfx sy = p->client_pxl_sy;
		n_type_gfx  x = p->client_pxl_sx - p->scrollbar_pxl_sx;
		n_type_gfx  y = -p->offset_pxl_y;

		x  -= p->border_pxl_sx;
		y  += p->border_pxl_sy;
		//sx -= p->border_pxl_sx * 2;
		sy -= p->border_pxl_sy * 2;

		x += p->shadow_l;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }


		n_posix_bool onoff = ( ( p->page_pxl_tabbed_sy / p->cell_pxl_sy ) < p->txt.sy );

		if ( onoff )
		{

			double step = (double) p->cell_pxl_sy;
			double pos  = (double) p->scroll_pxl_tabbed_y;
			double page = (double) p->  page_pxl_tabbed_sy;
			double max  = (double) p->  last_pxl_tabbed_sy;

//n_win_txtbox_hwndprintf_literal( p, " %g %g ", p->vscr.pixel_thumb_original, p->vscr.pixel_thumb );

			n_win_scrollbar_parameter( &p->vscr, step, page, max, pos, n_posix_false );

		}

		// [x] : off for round rect
		//n_bmp_box( &p->bmp, x,y,sx,sy, n_bmp_colorref2argb( p->color_back_noselect ) );

		n_win_scrollbar_move  ( &p->vscr, x,y,sx,sy, n_posix_true );
		n_win_scrollbar_enable( &p->vscr,     onoff, n_posix_true );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %g ", p->vscr.rect_main.y );

	}


	return;
}

// internal
void
n_win_txtbox_draw_scrollbar_placeholder( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }


	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		// Vertical / Y

		n_type_gfx sx = p->scrollbar_pxl_sx;
		n_type_gfx sy = p->client_pxl_sy;
		n_type_gfx  x = p->client_pxl_sx - p->scrollbar_pxl_sx;
		n_type_gfx  y = -p->offset_pxl_y;

		x  -= p->border_pxl_sx;
		y  += p->border_pxl_sy;
		//sx -= p->border_pxl_sx * 2;
		sy -= p->border_pxl_sy * 2;

		x += p->shadow_l;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }

		n_bmp_box( &p->bmp, x,y,sx,sy, n_bmp_colorref2argb( p->color_back_noselect ) );

	}


	return;
}



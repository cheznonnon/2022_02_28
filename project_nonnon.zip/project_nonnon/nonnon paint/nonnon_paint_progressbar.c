// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	HWND         hgui;
	n_bmp        bmp;
	n_gdi        gdi;
	n_posix_char font[ LF_FACESIZE ];

	n_type_gfx   sx;
	n_type_gfx   sy;

	COLORREF     fg;
	COLORREF     bg;

	u32          timeout;

	n_posix_bool prev_no_round;

	double       slice;

	int          prev_percent;

} n_paint_progressbar;


#define n_paint_progressbar_zero( p ) n_memory_zero( p, sizeof( n_paint_progressbar ) )




static n_paint_progressbar *n_paint_progressbar_ptr = NULL;




void
n_paint_progressbar_size( n_type_gfx *ret_sx, n_type_gfx *ret_sy )
{

	n_type_gfx dsx,dsy; n_win_desktop_size( &dsx,&dsy );

	n_type_gfx sx = n_posix_min( dsx, dsy ) / 5;
	n_type_gfx sy; n_win_stdsize( NULL, &sy, NULL, NULL );

	if ( ret_sx != NULL ) { (*ret_sx) = sx; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

LRESULT CALLBACK
n_paint_progressbar_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_PRINTCLIENT :
	{
//break;
		n_paint_progressbar *p = n_paint_progressbar_ptr;
		if ( p == NULL ) { break; }

		n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );
	}
	break;


	case WM_CREATE :

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		n_win_init_literal( hwnd, "", "", "" );


		//n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );
		n_win_style_new( hwnd, WS_POPUP );

		{
			n_type_gfx sx,sy; n_paint_progressbar_size( &sx, &sy );
			n_win_set( hwnd, NULL, sx,sy, N_WIN_SET_CENTERING );
		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :
	{
		n_posix_bool onoff = n_posix_false;
		SystemParametersInfo( SPI_GETMENUFADE, 0, &onoff, 0 );

		if ( onoff )
		{
			int aw = n_AW_HIDE | n_AW_BLEND | n_AW_VER_NEGATIVE;
			n_win_animatewindow( hwnd, 0, aw );
		} else {
			ShowWindow( hwnd, SW_HIDE );
		}

		DestroyWindow( hwnd );
	}
	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}



void
n_paint_gdi_init( n_paint_progressbar *p )
{

	n_gdi_zero( &p->gdi );


	p->gdi.sx                  = p->sx;
	p->gdi.sy                  = p->sy;
	p->gdi.scale               = N_GDI_SCALE_AUTO;
	p->gdi.style               = N_GDI_DEFAULT;
	p->gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	p->gdi.align               = N_GDI_ALIGN_CENTER;

	p->gdi.base                = n_posix_literal( "" );
	p->gdi.base_index          = 0;
	p->gdi.base_color_bg       = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );
	p->gdi.base_color_fg       = n_win_dwm_windowcolor_arranged();
	p->gdi.base_style          = N_GDI_BASE_PROGRESS_H;

	n_posix_sprintf_literal( p->font, "%s", n_project_stdfont() );

	p->gdi.text_font           = p->font;
	p->gdi.text_size           = (n_type_gfx) ( (double) p->sy * 0.75 );
	p->gdi.text_style          = N_GDI_TEXT_BOLD | N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	p->gdi.text_color_main     = n_bmp_rgb( 255,255,255 );
	p->gdi.text_color_contour  = n_bmp_rgb(  10, 10, 10 );


	HDC hdc = GetDC( NULL );

	p->gdi.scale        = GetDeviceCaps( hdc, LOGPIXELSX ) / 96;
	p->gdi.text_fxsize1 = p->gdi.scale * 2;
	p->gdi.text_fxsize2 = p->gdi.scale * 2;

	ReleaseDC( NULL, hdc );


	return;
}

void
n_paint_gdi_loop( n_paint_progressbar *p, n_posix_char *str, int percent )
{

	p->gdi.text    = str;
	p->gdi.percent = percent;

	n_bmp_free( &p->bmp );
	n_gdi_bmp( &p->gdi, &p->bmp );


	return;
}

void
n_paint_progressbar_loop( n_paint_progressbar *p, double zero_one )
{

	if ( p->timeout < n_posix_tickcount() )
	{

		if ( p->hgui == NULL )
		{
			n_paint_gdi_init( p );

			n_win_gui( hwnd_main, WINDOW, n_paint_progressbar_wndproc, &p->hgui );
		}


		int pc_cur = (int) ceil( zero_one * 100 );

		n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d%%", pc_cur );
		n_paint_gdi_loop( p, str, pc_cur );

		n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );

/*
		int pc_cur = ceil( zero_one * 100 );
		int pc_prv = p->prev_percent;

		while( 1 )
		{

			n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d%%", pc_prv );
			n_paint_gdi_loop( p, str, pc_prv );

			n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );

			pc_prv++;
			if ( pc_prv >= pc_cur ) { break; }
		}

		p->prev_percent = pc_cur;
*/
	}


	return;
}

void
n_paint_progressbar_init( n_paint_progressbar *p )
{

	n_paint_progressbar_zero( p );


	p->timeout = n_posix_tickcount() + 1000;


	n_paint_progressbar_size( &p->sx, &p->sy );


	p->prev_no_round = n_game_progressbar_no_round;
	n_game_progressbar_no_round = n_true;

	n_game_progressbar_animation          = N_GAME_PROGRESSBAR_ANIMATION_ON_UP;
	n_game_progressbar_animation_interval = 10;


	p->slice = (double) 1 / n_paint_layer_count;


	p->prev_percent = 0;


	n_paint_progressbar_ptr = p;


	return;
}

void
n_paint_progressbar_exit( n_paint_progressbar *p )
{

	n_posix_sleep( 200 );

	n_win_message_send( p->hgui, WM_CLOSE, 0,0 );

	n_bmp_free_fast( &p->bmp );

	n_game_progressbar_no_round = p->prev_no_round;

	n_paint_progressbar_ptr = NULL;


	return;
}



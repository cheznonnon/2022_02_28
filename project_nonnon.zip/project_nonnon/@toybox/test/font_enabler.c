



// [Limitation]
//
//	current session only : not complete installation
//	buggy when run many times




#include <windows.h>




int
main( int argc, char *argv[] )
{

	if ( argc <= 1 ) { return 1; }


	int tmp = RemoveFontResource( argv[ 1 ] );

	if ( tmp )
	{
		SendMessage( HWND_BROADCAST, WM_FONTCHANGE, 0,0 );
	} else {
		MessageBox( NULL, "failed : RemoveFontResource()", "DEBUG", 0 );
	}


	tmp = AddFontResource( argv[ 1 ] );

	if ( tmp )
	{
		SendMessage( HWND_BROADCAST, WM_FONTCHANGE, 0,0 );
		MessageBox( NULL, "succeeded", "DEBUG", 0 );
	} else {
		MessageBox( NULL, "failed : AddFontResource()", "DEBUG", 0 );
	}


	return 0;
}


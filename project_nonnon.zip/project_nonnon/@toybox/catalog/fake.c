// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




void
n_ownerdraw_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, int id )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;


		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		HDC hdc = GetDC( hgui );


		HBRUSH hbrush = GetSysColorBrush( COLOR_BTNFACE );
		HICON  hicon  = LoadIcon( NULL, MAKEINTRESOURCE( IDI_APPLICATION ) );


		RECT r;
		int  x,y,sx,sy;


		GetClientRect( hgui, &r );
		x  = r.left;
		y  = r.top;
		sx = 40;
		sy = 40;


		if ( id == 0 )
		{
			UINT dc = DC_GRADIENT | DC_BUTTONS | DC_ACTIVE | DC_TEXT | DC_ICON;

			DrawCaption( hgui, hdc, &r, dc );
		} else

		if ( id == 1 )
		{
			DrawFrameControl( hdc, &r, DFC_CAPTION, DFCS_CAPTIONCLOSE );
		} else
		if ( id == 2 )
		{
			DrawFrameControl( hdc, &r, DFC_CAPTION, DFCS_CAPTIONHELP );
		} else
		if ( id == 3 )
		{
			DrawFrameControl( hdc, &r, DFC_SCROLL, DFCS_SCROLLSIZEGRIP );
		} else
		if ( id == 4 )
		{
			DrawFrameControl( hdc, &r, DFC_BUTTON, DFCS_BUTTONCHECK );
		} else
		if ( id == 5 )
		{
			DrawFrameControl( hdc, &r, DFC_BUTTON, DFCS_BUTTONRADIO );
		} else

		if ( id == 6 )
		{
			DrawEdge( hdc, &r, EDGE_RAISED, BF_RECT );
		} else
		if ( id == 7 )
		{
			DrawEdge( hdc, &r, EDGE_SUNKEN, BF_RECT );
		} else
		if ( id == 8 )
		{
			DrawEdge( hdc, &r, EDGE_ETCHED, BF_RECT );
		} else
		if ( id == 9 )
		{
			DrawEdge( hdc, &r, EDGE_BUMP,   BF_RECT );
		} else

		if ( id == 10 )
		{
			UINT ds = DST_ICON;
			DrawState( hdc, hbrush, NULL, (LPARAM) hicon,0, x,y,sx,sy, ds );
		} else
		if ( id == 11 )
		{
			UINT ds = DST_ICON | DSS_DISABLED;
			DrawState( hdc, hbrush, NULL, (LPARAM) hicon,0, x,y,sx,sy, ds );
		} else
		if ( id == 12 )
		{
			UINT ds = DST_ICON | DSS_DISABLED | DSS_UNION;
			DrawState( hdc, hbrush, NULL, (LPARAM) hicon,0, x,y,sx,sy, ds );
		} else
		if ( id == 13 )
		{
			UINT ds = DST_ICON | DSS_DISABLED | DSS_MONO;
			DrawState( hdc, hbrush, NULL, (LPARAM) hicon,0, x,y,sx,sy, ds );
		}

//TextOut( hdc, 0,0, "test", strlen( "test" ) );


		ReleaseDC( hgui, hdc );

	}
	break;


	} // switch


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int guimax       = 10;
	const int guimax_extra =  5;


	static HWND hgui[ 10 + 5 ];


	int i;


	switch( msg ) {


	case WM_CREATE :


		// window

		n_win_init( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,260, N_WIN_SET_CENTERING );


		// controls

		i = 0;
		while( 1 )
		{

			n_win_gui( hwnd, STATIC, "Nonnon", &hgui[ i ] );

			n_win_style_add( hgui[ i ], SS_OWNERDRAW );

			n_win_move_simple( hgui[ i ], 0, i * 20, 200,20, n_true );


			i++;
			if ( i >= guimax ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_win_gui( hwnd, STATIC, "", &hgui[ guimax + i ] );

			n_win_style_add( hgui[ guimax + i ], SS_OWNERDRAW );

			n_win_move_simple( hgui[ guimax + i ], 40 * i, ( guimax + 1 ) * 20, 40,40, n_true );


			i++;
			if ( i >= guimax_extra ) { break; }
		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :
	{

		RECT r = { 0, guimax * 20, 200, ( guimax * 20 ) + 20 };

		HDC hdc = GetDC( hwnd );


		DrawFocusRect( hdc, &r );


		ReleaseDC( hwnd, hdc );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	i = 0;
	while( 1 )
	{

		n_ownerdraw_proc( hwnd, msg, wparam, lparam, hgui[ i ], i );


		i++;
		if ( i >= ( guimax + guimax_extra ) ) { break; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

